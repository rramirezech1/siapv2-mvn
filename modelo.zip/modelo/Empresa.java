/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sv.gob.mined.apps.bnprove.mvn.modelo;

import java.util.Date;

/**
 *
 * @author InfoSoft
 */
public class Empresa {

    private Integer identificadorPrimarioDeLaEmpresa;
    private Integer identificadorDeLaOrganizacion;
    private Integer identificadorTipoEmpresa;
    private String pais;
    private Integer identificadorDePersoneria;
    private Integer identificadorDelRegimenDeAdmon;
    private String nombreComercial;
    private String razonSocial;
    private String numeroDeNit;
    private String direccionCompleta;
    private String codigo_departamento;
    private String numeroIVA;
    private Integer id_municipio;
    private String numeroIsssPatronal;
    private String numeroDeRegistroDeComercio;
    private String estadoOProvincia;
    private String razonSocialSegunEscritura;
    private String abreviaturaSegunEscritura;
    private Date fechaDeConstitucion;
    private String regimenDeAdministracion;
    private String correoElectronico;
    private String sitioWeb;
    private String telefonos;
    private String fax;
    private String numeroDeCelular;
    private String tipoDeEstablecimiento;
    private Integer esContribuyente;
    private Integer EstadoDeRegistro;
    private Date fechaDeInsercion;
    private Date fechaDeModificacion;
    private Date fechaDeEliminacion;
    private Integer estadoDeEliminacion;
    private String identificadorDeLaSesion;
    private String name;
    private Empresa emp;
    private Boolean contribuyente = false;

    public Empresa() {
    }

    public Empresa(Empresa emp) {
        this.emp = emp;
    }

    public Empresa getEmp() {
        return emp;
    }

    public void setEmp(Empresa emp) {
        this.emp = emp;
    }

    public Integer getEstadoDeRegistro() {
        return EstadoDeRegistro;
    }

    public void setEstadoDeRegistro(Integer EstadoDeRegistro) {
        this.EstadoDeRegistro = EstadoDeRegistro;
    }

    public String getAbreviaturaSegunEscritura() {
        return abreviaturaSegunEscritura;
    }

    public void setAbreviaturaSegunEscritura(String abreviaturaSegunEscritura) {
        this.abreviaturaSegunEscritura = abreviaturaSegunEscritura;
    }

    public String getCodigo_departamento() {
        return codigo_departamento;
    }

    public void setCodigo_departamento(String codigo_departamento) {
        this.codigo_departamento = codigo_departamento;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getDireccionCompleta() {
        return direccionCompleta;
    }

    public void setDireccionCompleta(String direccionCompleta) {
        this.direccionCompleta = direccionCompleta;
    }

    public Integer getEsContribuyente() {
        return esContribuyente;
    }

    public void setEsContribuyente(Integer esContribuyente) {
        this.esContribuyente = esContribuyente;
    }

    public Integer getEstadoDeEliminacion() {
        return estadoDeEliminacion;
    }

    public void setEstadoDeEliminacion(Integer estadoDeEliminacion) {
        this.estadoDeEliminacion = estadoDeEliminacion;
    }

    public String getEstadoOProvincia() {
        return estadoOProvincia;
    }

    public void setEstadoOProvincia(String estadoOProvincia) {
        this.estadoOProvincia = estadoOProvincia;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public Date getFechaDeConstitucion() {
        return fechaDeConstitucion;
    }

    public void setFechaDeConstitucion(Date fechaDeConstitucion) {
        this.fechaDeConstitucion = fechaDeConstitucion;
    }

    public Date getFechaDeEliminacion() {
        return fechaDeEliminacion;
    }

    public void setFechaDeEliminacion(Date fechaDeEliminacion) {
        this.fechaDeEliminacion = fechaDeEliminacion;
    }

    public Date getFechaDeInsercion() {
        return fechaDeInsercion;
    }

    public void setFechaDeInsercion(Date fechaDeInsercion) {
        this.fechaDeInsercion = fechaDeInsercion;
    }

    public Date getFechaDeModificacion() {
        return fechaDeModificacion;
    }

    public void setFechaDeModificacion(Date fechaDeModificacion) {
        this.fechaDeModificacion = fechaDeModificacion;
    }

    public Integer getId_municipio() {
        return id_municipio;
    }

    public void setId_municipio(Integer id_municipio) {
        this.id_municipio = id_municipio;
    }

    public Integer getIdentificadorDeLaOrganizacion() {
        return identificadorDeLaOrganizacion;
    }

    public void setIdentificadorDeLaOrganizacion(Integer identificadorDeLaOrganizacion) {
        this.identificadorDeLaOrganizacion = identificadorDeLaOrganizacion;
    }

    public String getIdentificadorDeLaSesion() {
        return identificadorDeLaSesion;
    }

    public void setIdentificadorDeLaSesion(String identificadorDeLaSesion) {
        this.identificadorDeLaSesion = identificadorDeLaSesion;
    }

    public Integer getIdentificadorDePersoneria() {
        return identificadorDePersoneria;
    }

    public void setIdentificadorDePersoneria(Integer identificadorDePersoneria) {
        this.identificadorDePersoneria = identificadorDePersoneria;
    }

    public Integer getIdentificadorDelRegimenDeAdmon() {
        return identificadorDelRegimenDeAdmon;
    }

    public void setIdentificadorDelRegimenDeAdmon(Integer identificadorDelRegimenDeAdmon) {
        this.identificadorDelRegimenDeAdmon = identificadorDelRegimenDeAdmon;
    }

    public Integer getIdentificadorTipoEmpresa() {
        return identificadorTipoEmpresa;
    }

    public void setIdentificadorTipoEmpresa(Integer identificadorTipoEmpresa) {
        this.identificadorTipoEmpresa = identificadorTipoEmpresa;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNombreComercial() {
        return nombreComercial;
    }

    public void setNombreComercial(String nombreComercial) {
        this.nombreComercial = nombreComercial;
    }

    public String getNumeroDeCelular() {
        return numeroDeCelular;
    }

    public void setNumeroDeCelular(String numeroDeCelular) {
        this.numeroDeCelular = numeroDeCelular;
    }

    public Integer getIdentificadorPrimarioDeLaEmpresa() {
        return identificadorPrimarioDeLaEmpresa;
    }

    public void setIdentificadorPrimarioDeLaEmpresa(Integer identificadorPrimarioDeLaEmpresa) {
        this.identificadorPrimarioDeLaEmpresa = identificadorPrimarioDeLaEmpresa;
    }

    public String getNumeroDeNit() {
        return numeroDeNit;
    }

    public void setNumeroDeNit(String numeroDeNit) {
        this.numeroDeNit = numeroDeNit;
    }

    public String getNumeroDeRegistroDeComercio() {
        return numeroDeRegistroDeComercio;
    }

    public void setNumeroDeRegistroDeComercio(String numeroDeRegistroDeComercio) {
        this.numeroDeRegistroDeComercio = numeroDeRegistroDeComercio;
    }

    public String getNumeroIVA() {
        return numeroIVA;
    }

    public void setNumeroIVA(String numeroIVA) {
        this.numeroIVA = numeroIVA;
    }

    public String getNumeroIsssPatronal() {
        return numeroIsssPatronal;
    }

    public void setNumeroIsssPatronal(String numeroIsssPatronal) {
        this.numeroIsssPatronal = numeroIsssPatronal;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    public String getRazonSocialSegunEscritura() {
        return razonSocialSegunEscritura;
    }

    public void setRazonSocialSegunEscritura(String razonSocialSegunEscritura) {
        this.razonSocialSegunEscritura = razonSocialSegunEscritura;
    }

    public String getRegimenDeAdministracion() {
        return regimenDeAdministracion;
    }

    public void setRegimenDeAdministracion(String regimenDeAdministracion) {
        this.regimenDeAdministracion = regimenDeAdministracion;
    }

    public String getSitioWeb() {
        return sitioWeb;
    }

    public void setSitioWeb(String sitioWeb) {
        this.sitioWeb = sitioWeb;
    }

    public String getTelefonos() {
        return telefonos;
    }

    public void setTelefonos(String telefonos) {
        this.telefonos = telefonos;
    }

    public String getTipoDeEstablecimiento() {
        return tipoDeEstablecimiento;
    }

    public void setTipoDeEstablecimiento(String tipoDeEstablecimiento) {
        this.tipoDeEstablecimiento = tipoDeEstablecimiento;
    }
    
    public void setContribuyente(Boolean contribuyente){
        setEsContribuyente(contribuyente?1:0);
        this.contribuyente = contribuyente;
    }
    
    public Boolean getContribuyente(){
        return contribuyente;
    }

    public String generarInsertSQL() {
        String query = "INSERT INTO dbo.Empresa (identificadorDeLaOrganizacion, identificadorTipoEmpresa, pais, identificadorDePersoneria, identificadorDelRegimenDeAdmon, nombreComercial, razonSocial, numeroDeNit, direccionCompleta, codigo_departamento, numeroIVA, id_municipio, numeroIsssPatronal, numeroDeRegistroDeComercio, estadoOProvincia, razonSocialSegunEscritura, abreviaturaSegunEscritura, fechaDeConstitucion, regimenDeAdministracion, correoElectronico, sitioWeb, telefonos, fax, numeroDeCelular, tipoDeEstablecimiento, esContribuyente, EstadoDeRegistro, fechaDeInsercion, fechaDeModificacion, fechaDeEliminacion, estadoDeEliminacion, identificadorDeLaSesion, name) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        return query;
    }

    public Object[] getDatosInsert() {
        return new Object[]{identificadorDeLaOrganizacion, identificadorTipoEmpresa, pais, identificadorDePersoneria, identificadorDelRegimenDeAdmon, nombreComercial, razonSocial, numeroDeNit, direccionCompleta, codigo_departamento, numeroIVA, id_municipio, numeroIsssPatronal, numeroDeRegistroDeComercio, estadoOProvincia, razonSocialSegunEscritura, abreviaturaSegunEscritura, fechaDeConstitucion, regimenDeAdministracion, correoElectronico, sitioWeb, telefonos, fax, numeroDeCelular, tipoDeEstablecimiento, esContribuyente, EstadoDeRegistro, fechaDeInsercion, fechaDeModificacion, fechaDeEliminacion, estadoDeEliminacion, identificadorDeLaSesion, name};
    }

    public String generarUpdateSQL() {
        String query = "UPDATE dbo.Empresa SET identificadorDeLaOrganizacion=" + emp.getIdentificadorDeLaOrganizacion() + ", identificadorTipoEmpresa=" + emp.getIdentificadorTipoEmpresa() + ", pais=" + emp.getPais() + ", identificadorDePersoneria=" + emp.getIdentificadorDePersoneria() + ", identificadorDelRegimenDeAdmon=" + emp.getIdentificadorDelRegimenDeAdmon() + ", nombreComercial=" + emp.getNombreComercial() + ", razonSocial=" + emp.getRazonSocial() + ", numeroDeNit=" + emp.getNumeroDeNit() + ", direccionCompleta=" + emp.getDireccionCompleta() + ", codigo_departamento=" + emp.getCodigo_departamento() + ",numeroIVA=" + emp.getNumeroIVA() + ", id_municipio=" + emp.getId_municipio() + ", numeroIsssPatronal=" + emp.getNumeroIsssPatronal() + ", numeroDeRegistroDeComercio=" + emp.getNumeroDeRegistroDeComercio() + ", estadoOProvincia=" + emp.getEstadoOProvincia() + ", razonSocialSegunEscritura=" + emp.getRazonSocialSegunEscritura() + ", abreviaturaSegunEscritura=" + emp.getAbreviaturaSegunEscritura() + ", fechaDeConstitucion=" + emp.getFechaDeConstitucion() + ", regimenDeAdministracion=" + emp.getRegimenDeAdministracion() + ", correoElectronico=" + emp.getCorreoElectronico() + ", sitioWeb=" + emp.getSitioWeb() + ", telefonos=" + emp.getTelefonos() + ", fax=" + emp.getFax() + ", numeroDeCelular=" + emp.getNumeroDeCelular() + ", tipoDeEstablecimiento=" + emp.getTipoDeEstablecimiento() + ", esContribuyente=" + emp.getEsContribuyente() + ", EstadoDeRegistro=" + emp.getEstadoDeRegistro() + ", fechaDeInsercion=" + emp.getFechaDeInsercion() + ", fechaDeModificacion=" + emp.getFechaDeModificacion() + ", fechaDeEliminacion=" + emp.getFechaDeEliminacion() + ", estadoDeEliminacion=" + emp.getEstadoDeEliminacion() + ", identificadorDeLaSesion=" + emp.getIdentificadorDeLaSesion() + ", name=" + emp.getName() + "Where identificadorPrimarioDeLaEmpresa=" + emp.getIdentificadorPrimarioDeLaEmpresa() + "";
        return query;
    }
}